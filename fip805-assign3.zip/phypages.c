#include "phypages.h"
#include "pagetable.h"
#include <stdlib.h>
#include <string.h>

#define NUM_FRAMES 8

typedef struct {
    int page_number;
    int last_used;
} Frame;

static Frame frames[NUM_FRAMES];
static int time_counter = 0;

void initialize_phypages() {
    for (int i = 0; i < NUM_FRAMES; i++) {
        frames[i].page_number = -1;  // -1 indicates the frame is free
        frames[i].last_used = -1;
    }
}

int allocate_frame(int page_number) {
    time_counter++;
    for (int i = 0; i < NUM_FRAMES; i++) {
        if (frames[i].page_number == -1) {
            frames[i].page_number = page_number;
            frames[i].last_used = time_counter;
            return i;
        }
    }

    int lru_index = 0;
    for (int i = 1; i < NUM_FRAMES; i++) {
        if (frames[i].last_used < frames[lru_index].last_used) {
            lru_index = i;
        }
    }

    invalidate_page(frames[lru_index].page_number);
    frames[lru_index].page_number = page_number;
    frames[lru_index].last_used = time_counter;
    return lru_index;
}

void update_frame_usage(int frame_number) {
    time_counter++;
    frames[frame_number].last_used = time_counter;
}

