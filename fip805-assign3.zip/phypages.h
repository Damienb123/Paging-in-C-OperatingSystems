#ifndef PHYPAGES_H
#define PHYPAGES_H

void initialize_phypages();
int allocate_frame(int page_number);
void update_frame_usage(int frame_number);

#endif

